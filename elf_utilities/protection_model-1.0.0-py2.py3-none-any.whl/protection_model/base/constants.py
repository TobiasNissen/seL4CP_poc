"""
    The offset measured in bytes from the beginning of an ELF file
    to the field where the offset of the access rights section is written.
"""
EI_ACCESS_RIGHTS_OFFSET_IDX = 9
